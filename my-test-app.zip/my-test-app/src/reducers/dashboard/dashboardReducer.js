const initialState = {
    statusCode: 0,
    PropertiesList:[],
    successMessage: null,
    failureMessage: null,
  };
  
  function dashboardReducer(state = initialState, action) {
    switch (action.type) {
      case 'DASHBOARD_FETCH_REQUEST':
        return Object.assign({}, state, {
           statusCode: 0,
           PropertiesList:[],
          successMessage: null,
          failureMessage: null,
        });
  
      case 'DASHBOARD_FETCH_SUCCESS':
        return Object.assign({}, state, {
          statusCode: 200,
          PropertiesList:action.result,
          successMessage: 'Fetched data successfully',
          failureMessage: null,
        });
  
      case 'DASHBOARD_FETCH_FAILURE':
        return Object.assign({}, state, {
          PropertiesList:[],
          statusCode: action.error.statusCode,
          successMessage: null,
          failureMessage: action.error.statusMessage,
        });
      default:
        return state;
    }
  }
  
  export default dashboardReducer;
  