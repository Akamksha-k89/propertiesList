import React, { Component } from 'react';
import Paper from 'react-md/lib/Papers';

export class PropertyTile extends Component {
    constructor(props) {
        super(props);
        this._redirectToPropertyDetailsSections = this._redirectToPropertyDetailsSections.bind(
          this
        );
    }
    _redirectToPropertyDetailsSections() {
      this.props.redirectToPropertyDetails(this.props.property.id);
      }

      _formatAddress(addressToBeformatted)
      {
        if(addressToBeformatted)
        {
            return  (`${addressToBeformatted.address1?addressToBeformatted.address1:''} ${addressToBeformatted.address2?addressToBeformatted.address2:''}\n${addressToBeformatted.city?addressToBeformatted.city:''},${addressToBeformatted.state?addressToBeformatted.state:''} ${addressToBeformatted.zip?addressToBeformatted.zip:''}`);
        }
      }
      _calculateYield(monthlyRent,listPrice)
      {
        
          if(!isNaN(monthlyRent) && !isNaN(listPrice) && listPrice>0)
          {
                return ((monthlyRent*12)/listPrice).toFixed(2);
          }
      }
  render() {
    let property = this.props.property;
    let Address = this._formatAddress(property.Address);  
    return (
      
        <Paper
          key={property.id}
          zDepth={1}
          raiseOnHover={true}
          className="paper-protocol"
        >
        <div className="Imgcontainer">
        <a href="javascript:void(0)" onClick={this._redirectToPropertyDetailsSections}>
        <img src={property.mainImageUrl} className="property-image" />
        </a>
        </div>
        <div className="propertyStatus">
        <div className="year-built">
        <h6>Year Built:</h6>
        <span>{property.yearBuilt}</span>
        </div>
        <div className="gross-yield">
        <h6>Gross Yield:</h6>
        <span>{this._calculateYield(property.monthlyRent,property.listPrice)} </span>
        </div>
        </div>
        <div className="propertyStatus">
        <div className="list-price">
        <h6>List Price:</h6>
        <span>{property.listPrice.toFixed(2)}</span>
        </div>
        <div className="monthly-rent">
        <h6>Monthly Rent:</h6>
        <span>{property.monthlyRent.toFixed(2)}</span>
        </div>
        </div>
        <div className="propertyStatus">
        <div className="address">
        <h6>Address:</h6>
        <span>{Address}</span>
        </div>
        </div>
        </Paper>
      
    );
  }
}


export default PropertyTile;
