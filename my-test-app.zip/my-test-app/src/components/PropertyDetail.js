import React, { Component } from 'react';
import Carousel from 'nuka-carousel';
import '../assets/stylesheets/PropertyDetails.scss';
export class PropertyDetails extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            imagesList:[],
            address:'',
        };
        
    }
    componentDidMount()
    {
        this._fetchimages();
    }
    _fetchimages()
    {
        const {match,PropertiesList } = this.props;
        let propertyRender=[];
        if (match.params.id && PropertiesList.length>0 ) {
            let PropertyDetail = PropertiesList.filter(item=>item.id.toString()===match.params.id);
            if(PropertyDetail && PropertyDetail[0].resources && PropertyDetail[0].resources.photos && PropertyDetail[0].resources.photos.length>0)
            {
                propertyRender =PropertyDetail[0].resources.photos.map(                                                   (item)=>{
                    return item.url});    
                    let address = PropertyDetail[0].address ?this._formatAddress(PropertyDetail[0].address):'';
                    this.setState({imagesList:propertyRender,address:address});
            }
            
        }
    }
    _formatAddress(addressToBeformatted)
    {
      if(addressToBeformatted)
      {
          return  (`${addressToBeformatted.address1?addressToBeformatted.address1:''} ${addressToBeformatted.address2?addressToBeformatted.address2:''}\n${addressToBeformatted.city?addressToBeformatted.city:''},${addressToBeformatted.state?addressToBeformatted.state:''} ${addressToBeformatted.zip?addressToBeformatted.zip:''}`);
      }
    }
     
       render(){
      let propertyRender = this.state.imagesList.length>0?(
      this.state.imagesList.map((item,index) =>{return <img key={"list"+index} src={item} alt=""/>}) 
       ) :''; 
        return <div className="propertyDetailsDisplay">
                {/* <div className="hide">
                {this.state.imagesList}
                </div> */}
                <div className="carouselDisplay">{propertyRender !== '' ?<Carousel cellAlign="center" >{propertyRender}</Carousel> : '' }</div>
                <div className="addressDetail">
                <h6>Address:</h6>
                {this.state.address}
                </div>
                </div>
        
        
      }
    
}
  export default PropertyDetails;



