import React, { Component } from 'react';
import '../assets/stylesheets/Dashboard.scss';

import PropertyTile from './PropertyTile';

export class Dashboard extends Component {
  constructor(props)
  {
    super(props);
    this.redirectToPropertyDetails = this.redirectToPropertyDetails.bind(this);
  }
  redirectToPropertyDetails(id) {
       this.props.history.push('/Property/' +id);
    }
  render() {
    let PropertyListRender=[];
    let propertiesList= this.props.PropertiesList.filter((property)=>{
        return (property.accountId!==0 && property.financial)
      })
     PropertyListRender = propertiesList.map((item, index) => {
       let property= {
          id:item.id,
          mainImageUrl:item.mainImageUrl,
          Address:item.address,
          yearBuilt: (item.physical  && item.physical.yearBuilt)?item.physical.yearBuilt:'',
          monthlyRent:(item.financial.monthlyRent)?item.financial.monthlyRent:'',
          listPrice:(item.financial.listPrice)?item.financial.listPrice:'',
        };
      
          return   (<PropertyTile
            property={property}
            key={`active${index}`}
            redirectToPropertyDetails={this.redirectToPropertyDetails}
          />
        )   
      });
return (
    <div >{PropertyListRender}</div>
);
}
}
 export default Dashboard;
