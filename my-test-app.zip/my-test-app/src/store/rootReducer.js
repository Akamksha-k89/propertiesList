import { combineReducers } from 'redux';
import dashboardReducer from '../reducers/dashboard/dashboardReducer';
const appReducer = combineReducers({
  dashboardReducer,
});
const root = (state, action) => {
   return appReducer(state, action);
};

export default root;
