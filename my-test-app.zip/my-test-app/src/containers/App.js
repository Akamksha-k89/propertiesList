import React, { Component } from 'react';
import { Route} from 'react-router';
import Dashboard from '../components/Dashboard';
import  PropertyDetails  from '../components/PropertyDetail';
import { fetchDashboard } from '../actions/dashboard/dashboard';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
export class App extends Component {
  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(
      fetchDashboard()
    );
  }
  render() {
    let routes=[];
    let {PropertiesList}=this.props;
    if(PropertiesList.length>0)
    {
      routes=[
          <Route
          key="Dashboard"
            exact
            path="/"
            render={(props)=>{
               return <Dashboard {...props} PropertiesList={PropertiesList} />}}
            />,
             <Route
             key="PropertyDetails"
            exact
            path="/Property/:id?"
            render={(props)=><PropertyDetails  {...props}  PropertiesList={PropertiesList}/>}
            />
      ];
    }
      return (
        <div className="app">
          {routes}
        </div>
      )
}
}
function mapStateToProps(state) {
  return {
    PropertiesList: state.dashboardReducer.PropertiesList,
    };
}
 export default withRouter(connect(mapStateToProps)(App));
