import request from 'superagent'

export function fetchRequest() {
    return { type: 'DASHBOARD_FETCH_REQUEST' };
  }
  
  export function fetchSuccess(result) {
    return { type: 'DASHBOARD_FETCH_SUCCESS', result };
  }
  
  export function fetchFailure(error) {
    return { type: 'DASHBOARD_FETCH_FAILURE', error };
  }
  export function fetchDashboard() {
    return function(dispatch) {
      dispatch(fetchRequest());
      request.get('http://dev1-sample.azurewebsites.net/properties.json',{mode:"no-cors"}).end((err, res) => {
        if (err) {
            /*
            in case there is any error, dispatch an action containing the error
            */
           return dispatch(fetchFailure(err));
           
          }
          const data = JSON.parse(res.text);
          dispatch(fetchSuccess(data.properties));
      });
    }
  }
  